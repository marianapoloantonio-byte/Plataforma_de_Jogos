﻿using System;

class Usuario
{
    public int Id;
    public string Nome;
    public string Email;
    public string Senha;
    public Biblioteca Biblioteca;

// -------- Construtor --------
    public Usuario(int id, string nome, string email, string senha)
    {
        Id = id;
        Nome = nome;
        Email = email;
        Senha = senha;
    }

// Metodo para exibir os dados do usuario
    public void ExibirDados()
    {
        
    }
}

class Jogo
{
    public int Id;
    public string Nome;
    public double Preco;
    public Categoria Categoria;

// -------- Construtor --------
    public Jogo(int id, string nome, double preco)
    {
        Id = id;
        Nome = nome;
        Preco = preco;
    }
// Metodo para exibir informaçoes do jogo
    public void ExibirInformacoes()
    {
        
    }
}

class Categoria
{
    public int Id;
    public string Nome;

}

class Biblioteca
{
    
}

class Compra
{
    public int Id;
    public Usuario Usuario;
    public Jogo Jogo;
    public double ValorPago;

// -------- Construtor --------
    public Compra(int id, Usuario usuario, Jogo jogo)
    {
        Id = id;
        Usuario = usuario;
        Jogo = jogo;
    }

// Metodo para finalizar a compra e adicionar o jogo na biblioteca do usuario
    public void FinalizarCompra()
    {
        
    }
}
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Funcionando");
    }
}